namespace BeansCuest {
    type LocationName = "cloud" | "lilypond" | "mansion" | "mansion2" | "meadow" | "meadow2" | "wistfulwoods" | "wistfulwoods2" | "wistfulwoods3" | "woods" | "woods2" | "woods3" | "black" | "otherworld";
    type Location<T extends LocationName> = {
        name: T,
        background: `Images/Backgrounds/${T}.png`
    }
    type LocationDefinition = Record<LocationName, Location<LocationName>>;
    export let LOCATIONS: LocationDefinition = {
        cloud: {
            name: "cloud",
            background: "Images/Backgrounds/cloud.png"
        },
        lilypond: {
            name: "lilypond",
            background: "Images/Backgrounds/lilypond.png"
        },
        mansion: {
            name: "mansion",
            background: "Images/Backgrounds/mansion.png"
        },
        mansion2: {
            background: "Images/Backgrounds/mansion2.png",
            name: "mansion2",
        },
        meadow: {
            background: "Images/Backgrounds/meadow.png",
            name: "meadow"
        },
        meadow2: {
            background: "Images/Backgrounds/meadow2.png",
            name: "meadow2"
        },
        wistfulwoods: {
            name: "wistfulwoods",
            background: "Images/Backgrounds/wistfulwoods.png"
        },
        woods: {
            background: "Images/Backgrounds/woods.png",
            name: "woods"
        },
        woods2: {
            background: "Images/Backgrounds/woods2.png",
            name: "woods2"
        },
        woods3: {
            background: "Images/Backgrounds/woods3.png",
            name: "woods3"
        },
        black: {
            background: "Images/Backgrounds/black.png",
            name: "black",
        },
        otherworld: {
            background: "Images/Backgrounds/otherworld.png",
            name: "otherworld"
        },
        wistfulwoods2: {
            background: "Images/Backgrounds/wistfulwoods2.png",
            name: "wistfulwoods2",
        },
        wistfulwoods3: {
            background: "Images/Backgrounds/wistfulwoods3.png",
            name: "wistfulwoods3"
        }
    }
}